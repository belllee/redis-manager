<template>
  <div id="app">
    <el-container direction="vertical">
      <el-header>
        <h2 style="margin:0;">Redis manager</h2>
      </el-header>
      <el-container>
        <el-main>
          <redis-app></redis-app>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import RedisApp from './components/RedisApp'
export default {
  name: 'redis-manager',
  components: {
    RedisApp
  }
}
</script>

<style>
  .el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
  }
  
  .el-aside {
    color: #333;
  }
</style>
