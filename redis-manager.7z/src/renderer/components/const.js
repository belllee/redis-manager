export default {
  TEMPLATE: {
    single: `{
"port": 6379,
"password": "123456",
"host": "127.0.0.1"
}`,
    cluster: `[{"port":6379,"password":"123456","host":"10.10.10.1"},
{"port":6379,"password":"123456","host":"10.10.10.2"},
{"port":6379,"password":"123456","host":"10.10.10.3"}]`,
    sentinel: `{"sentinels":[
{"host":"10.10.10.1","port":26379},
{"host":"10.10.10.2","port":26379},
{"host":"10.10.10.3","port":26379}],
"name":"contentmaster",
"password":"123456"}`
  },
  CONNECT_MODE_LIST: ['single', 'cluster', 'sentinel'],
  CONNECT_MODE: {
    SINGLE: 'single', CLUSTER: 'cluster', SENTINEL: 'sentinel'
  }
}
