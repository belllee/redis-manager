const Redis = require('ioredis')

class RedisService {
  constructor () {
    this.connectCounter = 0
    this.redisMode = ''
    this.isSingle = true
    this.cluster = null
    this.currentConfig = null
  }

  connect (config, result) {
    try {
      let me = this
      return new Promise((resolve, reject) => {
        if (!config) {
          reject(new Error('配置信息为空'))
          return
        } else if (config instanceof Array) {
          for (let i = 0, c; (c = config[i]); i++) {
            c.connectTimeout = 0
          }
          me.redisMode = 'cluster'
          me.isSingle = false

          me.cluster = new Redis.Cluster(config)
        } else if (config instanceof Object) {
          if (config.name && config.sentinels) {
            me.redisMode = 'sentinel'
            me.isSingle = true
            config.connectTimeout = 0
            me.cluster = new Redis(config)
          } else if (config.host && config.port) {
            me.redisMode = 'single'
            me.isSingle = true
            config.connectTimeout = 0
            me.cluster = new Redis(config)
          } else {
            reject(new Error('无效的配置信息'))
            return
          }
        } else {
          reject(new Error('无效的配置信息'))
          return
        }
        this.currentConfig = config
        me.connectCounter = 0
        console.log('***  initCluster  ***')
        me.cluster.on('connect', function (e) {
          console.log('connected', e, me.cluster)
          if (me.redisMode === 'single') {
            resolve(me.handleSingleConnect(me.cluster))
          } else if (me.redisMode === 'sentinel') {
            if (me.connectCounter === 0) {
              resolve(me.handleSingleConnect(me.cluster))
            }
            me.connectCounter = 1
          } else {
            let nodes = me.cluster.nodes('master')
            resolve(me.handleClusterConnect(nodes, result))
          }
        })
        me.cluster.on('error', function (err) {
          console.error('REDIS CONNECT error ' + err)
          console.error('node error', err.lastNodeError)
        })
      })
    } catch (e) {
      console.error(e)
    }
  }

  close () {
    if (this.cluster) {
      this.cluster.disconnect()
      this.cluster = null
    }
  }

  handleSingleConnect (node) {
    return new Promise((resolve, reject) => {
      let data = {
        master: node.options.host,
        currentDB: node.options.db,
        dbs: []
      }
      let dbMatch = null
      node.info().then((d) => {
        // console.log('info',d)
        dbMatch = d.match(/db[\d]{1,2}:.+/ig)
        if (dbMatch) {
          for (let i = 0, len = dbMatch.length; i < len; i++) {
            let label = dbMatch[i].substring(0, dbMatch[i].indexOf(','))
            let number = parseInt(dbMatch[i].substring(2, dbMatch[i].indexOf(':')))
            data.dbs[i] = {label, number}
          }
        }
        resolve(data)
      }).catch(e => reject(e))
    })
  }
  handleClusterConnect (nodes, res) {
    console.log('handleCluster', nodes)
    let promiseList = []
    for (let i = 0, node; (node = nodes[i]); i++) {
      console.log('node.condition', node.condition)
      // if (!node.condition || !node.condition.auth) {
      //   continue
      // }
      let p = new Promise((resolve, reject) => {
        let master = node.options.host
        let slaves = []
        node.info().then((d) => {
          slaves = d.match(/slave[\d]{1}:ip=[\d.]{7,}/ig)
          console.log('cluster info', slaves)
          if (slaves) {
            for (let i = 0, len = slaves.length; i < len; i++) {
              slaves[i] = slaves[i].replace('ip=', '')
            }
          }
          resolve({master, slaves})
        })
      })
      promiseList.push(p)
    }
    return new Promise((resolve, reject) => {
      Promise.all(promiseList).then((result) => {
        console.log(result)
        resolve(result)
        res = result
      }).catch((error) => {
        console.log('handleCluster fail', error)
        resolve(error)
      })
    })
  }
  excuteWapper (cmdStr) {
    let me = this
    return new Promise((resolve, reject) => {
      var masters = null
      if (!cmdStr) {
        reject(new Error('命令不能为空'))
        return
      }
      let cmdTmp = cmdStr.split(' ')
      let cmdArray = []
      // console.log(cmdTmp)
      for (let i = 0, len = cmdTmp.length; i < len; i++) {
        if (cmdTmp[i]) {
          cmdArray.push(cmdTmp[i])
        }
      }
      if (cmdArray.length < 1) {
        reject(new Error('命令不能为空'))
        return
      }
      // console.log(cmdArray)
      if (me.isSingle) {
        masters = [me.cluster]
      } else {
        masters = me.cluster.nodes('master')
      }

      Promise.all(masters.map(function (node) {
        return new Promise(function (resolve, reject) {
          console.log('excute node', node)
          node.sendCommand(
            new Redis.Command(
              cmdArray[0],
              cmdArray.length === 1 ? [] : cmdArray.slice(1),
              'utf-8',
              function (err, value) {
                if (err) {
                  reject(err)
                  return
                }
                // console.log(value)
                resolve(value ? value.toString() : '')
              }
            )
          )
        })
      })).then((result) => {
        // console.log('eee1', result)
        resolve(result)
      }).catch((error) => {
        // console.log('excute cmd fail', error)
        reject(error)
      })
    })
  }
  excute (cmdStr, currentDB) {
    let me = this
    if (me.redisMode === 'sentinel' || me.cluster.options.db === currentDB) {
      return me.excuteWapper(cmdStr)
    } else {
      return new Promise((resolve, reject) => {
        this.currentConfig.db = currentDB
        me.connect(this.currentConfig).then(d => {
          me.excuteWapper(cmdStr).then(r => {
            // console.log('excute su', r)
            resolve(r)
          }).catch(e => {
            reject(e)
            // console.log('excute error1', e)
          })
        }).catch(e => {
          reject(e)
          // console.log('excute error2', e)
        })
      })
    }
  }
  queryWapper (key) {
    let me = this
    return new Promise(function (resolve, reject) {
      // console.log(me)
      let masters = null
      if (me.isSingle) {
        masters = [me.cluster]
      } else {
        masters = me.cluster.nodes('master')
      }
      let keys = []
      Promise.all(masters.map(function (node) {
        return new Promise(function (resolve, reject) {
          node.keys(key, function (err, res) {
            err && console.log('keys error', err)
            keys = keys.concat(res)
            resolve()
          })
        })
      })).then(() => {
        // console.log('keys end')
        if (keys.length === 0) {
          reject(new Error('无匹配的关键字'))
        } else if (keys.length === 1) {
          resolve(me.queryKey(keys))
        } else {
          resolve(keys)
        }
      })
    })
  }
  query (cmdStr, currentDB) {
    let me = this
    if (me.redisMode === 'sentinel' || me.cluster.options.db === currentDB) {
      return me.queryWapper(cmdStr)
    } else {
      return new Promise((resolve, reject) => {
        this.currentConfig.db = currentDB
        me.connect(this.currentConfig).then(d => {
          me.queryWapper(cmdStr).then(r => {
            // console.log('success1', r)
            resolve(r)
          }).catch(e => {
            reject(e)
            // console.log('error1', e)
          })
        }).catch(e => {
          reject(e)
          // console.log('error2', e)
        })
      })
    }
  }
  queryKey (key) {
    let me = this
    return new Promise(function (resolve, reject) {
      me.cluster.type(key, function (err, res) {
        err && console.log('type', err)
        let type = res
        // currentKey = key
        switch (type) {
          case 'string':
            me.cluster.get(key, (err, data) => {
              err && reject(err)
              resolve({type, data})
            })
            break
          case 'hash':
            me.cluster.hgetall(key, (err, data) => {
              err && reject(err)
              resolve({type, data})
            })
            break
          case 'list':
            me.cluster.lrange(key, 0, 99999, (err, data) => {
              err && reject(err)
              resolve({type, data})
            })
            break
          case 'set':
            me.cluster.smembers(key, (err, data) => {
              err && reject(err)
              resolve({type, data})
            })
            break
          case 'zset':
            me.cluster.zrange(key, 0, 99999, (err, data) => {
              err && reject(err)
              resolve({type, data})
            })
            break
          default:
            console.log('未知类型=', type)
            reject(new Error('未知类型=', type))
        }
      })
    })
  }

  queryTtl (key) {
    let me = this
    return new Promise(function (resolve, reject) {
      me.cluster.ttl(key, function (err, res) {
        err && console.log('ttl error', err)
        resolve(res)
      })
    })
  }

  delData (key) {
    let me = this
    return new Promise(function (resolve, reject) {
      me.cluster.del(key, function (err, res) {
        console.log('del', err, res)
        if (err) {
          console.log(err)
          reject(err)
        }
        resolve(res)
      })
    })
  }
}
export default new RedisService()
