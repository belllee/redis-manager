class Storage {
  save (key, value) {
    let data = {
      value,
      timestamp: new Date().getTime()
    }
    window.localStorage.setItem(key, JSON.stringify(data))
  }

  read (key, timeout) {
    let dataStr = window.localStorage.getItem(key)
    if (!dataStr) {
      return null
    }
    let data = JSON.parse(dataStr)
    let now = new Date().getTime()
    if (!data || !data.timestamp || (timeout && now - timeout > data.timestamp)) {
      return null
    }
    return data.value
  }
}

export default new Storage()
