<template>
  <el-row :gutter="20">
    
    <el-col :span="5" class="connectlist">
      <h3>Redis连接</h3>
      <ul role="menubar" class="el-menu">
        <li role="menuitem" class="el-menu-item add-box">
          <el-button @click="dialogVisible = true" type="success" plain><i class="el-icon-plus"></i>添加</el-button>
        </li>
        <li role="menuitem" class="el-menu-item" :class="{'is-active': currentIndex == index}" v-for="(c,index) in configList" :key="c.name" @click="doConnect(index)">
          <el-row>
            <el-col :span="14">
              <i class="el-icon-document"></i><span>{{c.name}}</span>
            </el-col>
            <el-col :span="10">
              <el-button @click.stop="modifyConfig(index)" type="primary" plain>编辑</el-button>
              <el-button @click.stop="deleteConfg(index)" type="danger" plain>删除</el-button>
            </el-col>
          </el-row>
        </li>
      </ul>
    </el-col>
    <el-col :span="5">
      <div class="">连接状态：{{state}}</div>
      <div v-if="!connectInfoArray.length">
        <div class="">Master：{{connectInfo.master}}</div>
        <div style="margin-bottom:10px;">
          <el-radio class="dbinfo" v-model="connectInfo.currentDB" :label="db.number" v-for="db in connectInfo.dbs" :key="db.number">{{db.label}}</el-radio>
        </div>
      </div>
      <div v-if="connectInfoArray.length">
        <div v-for="d in connectInfoArray" :key="d.master">
          <H3>Master:{{d.master}}</H3>
          <div v-for="s in d.slaves" :key="s">{{s}}</div>
          </div>
        </div>
    </el-col>
    <el-col :span="14">
      <div>
        <el-radio v-model="mode" label="cmd">原生命令</el-radio>
        <el-radio v-model="mode" label="query">智能查询</el-radio>
      </div>
      <div class="gen-para">
        <el-form ref="form" label-width="120px">
          <el-row :gutter="5">
            <el-col :span="18">
              <el-input v-model="cmd" @keyup.enter="doExcute"></el-input>
            </el-col>
            <el-col :span="6">
              <el-button type="primary" @click="doExcute">执行</el-button>
            </el-col>
          </el-row>
        </el-form>
        <div v-if="mode !== 'cmd'" style="margin:20px 0;">
          <el-row>
            <el-col :span="6">
              数据类型：<span>{{query.type}}</span>
            </el-col>
            <el-col :span="6">
              Size：<span>{{query.size}}</span>
            </el-col>
            <el-col :span="6">
              TTL：<span>{{query.ttl}}</span>
            </el-col>
            <el-col :span="6">
              <el-button @click.stop="deleteData()" type="danger" plain>删除</el-button>
            </el-col>
          </el-row>
          <div style="height:300px; width:90%;border:solid 1px #e3e3e3;margin-top:20px;">
            <ul v-if="query.list.length>0">
              <li v-for="l in query.list" :key="l">{{l}}</li>
            </ul>
            <div>
              {{query.result}}
            </div>
          </div>
        </div>
      </div>
      <div>
        <h4>执行记录：<el-button @click="clearMessage()" plain>清空</el-button>
        </h4>
        <textarea name="message" ref="message" style="width:90%" :rows="messageRows" v-model="message" onpropertychange="this.scrollTop = this.scrollHeight " onfocus="this.scrollTop =  this.scrollHeight "></textarea>
      </div>
    </el-col>
    
    <el-dialog title="Redis连接信息配置" :visible.sync="dialogVisible" width="35%" :before-close="handleClose">
      <el-form ref="form" label-width="80px">
        <el-form-item label="连接名称">
          <el-input v-model="configName" placeholder="连接名称"></el-input>
        </el-form-item>
      </el-form>
      <div style="margin-bottom:10px;" v-if="!isModify">
        <el-radio v-model="connectMode" :label="m" v-for="m in connectModeList" :key="m">{{m}}</el-radio>
      </div>
      <textarea style="width:100%" rows="7" v-model="configStr"></textarea>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="doSave()">确 定</el-button>
      </span>
    </el-dialog> 
  </el-row>
</template>

<script>
// import storage from '@/components/storage'
import CONST from '@/components/const'
// import Redis from '@/components/redis'
// import { setTimeout } from 'timers'

// const REDIS_CONFIG = 'REDIS_CONFIG'

export default {
  data () {
    return {
      state: '未连接',
      message: '',
      cmd: '',
      tips: '',
      mode: 'cmd',
      db: '',
      currentIndex: 'a',
      dialogVisible: false,
      isModify: false,
      modifyIndex: 0,
      connectModeList: CONST.CONNECT_MODE_LIST,
      connectMode: CONST.CONNECT_MODE.SINGLE,
      configStr: '',
      configName: '',
      configList: [],
      connectInfo: {},
      connectInfoArray: [],
      query: {
        type: '',
        size: '',
        ttl: '',
        result: '',
        list: []
      }
    }
  }
  /* created () {
    this.init()
    let db = storage.read(REDIS_CONFIG)
    console.log(db)
    if (db) {
      this.configList = db
    }
  },
  computed: {
    messageRows () {
      return this.mode === 'cmd' ? 30 : 10
    }
  },
  watch: {
    connectMode: {
      handler (n, o) {
        n && (this.configStr = CONST.TEMPLATE[n])
      }
    }
  },
  methods: {
    init () {
      this.isModify = false
      this.modifyIndex = 0
      this.configName = ''
      this.configStr = CONST.TEMPLATE[this.connectMode]
    },
    doSave () {
      if (!this.configStr) {
        this.$message.error('配置信息不能为空!')
        return
      }
      if (!this.configName) {
        this.$message.error('连接名称不能为空!')
        return
      }
      let config = JSON.parse(this.configStr)
      if (!config || !(config instanceof Array || config instanceof Object)) {
        this.$message.error('配置信息错误!')
        return
      }
      let newConfig = {
        name: this.configName,
        config
      }
      if (this.isModify) {
        this.configList[this.modifyIndex] = newConfig
      } else {
        this.configList.push(newConfig)
      }
      this.dialogVisible = false
      storage.save(REDIS_CONFIG, this.configList)
      if (!this.isModify) {
        this.connectRedis(newConfig)
      }
      setTimeout(() => this.init(), 500)
    },
    handleClose () {
      this.init()
      this.dialogVisible = false
    },
    modifyConfig (index) {
      this.isModify = true
      this.modifyIndex = index
      this.dialogVisible = true
      this.configName = this.configList[index].name
      this.configStr = JSON.stringify(this.configList[index].config)
    },
    deleteConfg (index) {
      this.configList.splice(index, 1)
      storage.save(REDIS_CONFIG, this.configList)
      this.init()
    },
    doConnect (index) {
      this.currentIndex = index
      Redis.close()
      this.connectRedis(this.configList[index])
    },
    connectRedis (config, fn) {
      this.connectInfo = {}
      this.connectInfoArray = []
      Redis.connect(config.config, this.connectInfoArray).then(d => {
        if (Redis.isSingle) {
          this.connectInfo = d
        } else {
          this.connectInfoArray = d
        }

        this.state = '已连接'
        this.addMessage('连接成功')
        fn && fn()
      }).catch(e => {
        this.state = '连接失败'
        this.addMessage(e.message)
        console.log(e)
      })
    },
    addMessage (message) {
      let me = this
      this.message = this.message + '\n' + message
      setTimeout(() => {
        me.$refs.message && (me.$refs.message.scrollTop = me.$refs.message.scrollHeight)
      }, 200)
    },
    clearMessage () {
      this.message = ''
    },
    doExcute () {
      console.log(this.mode)
      if (this.mode === 'cmd') {
        this.addMessage('> ' + this.cmd)
        Redis.excute(this.cmd, this.connectInfo.currentDB)
          .then(d => this.showResult(d))
          .catch(e => this.addMessage(e.msg))
      } else {
        Redis.query(this.cmd, this.connectInfo.currentDB)
          .then(d => {
            this.showQueryResult(d)
            this.showResult(d)
          })
          .catch(e => {
            console.log('fal', e)
            this.addMessage(e.msg)
          })
      }
    },
    showResult (array) {
      let result = ''
      for (let i = 0, s; (s = array[i]); i++) {
        let a1 = s.split(',')
        for (let j = 0, s1; (s1 = a1[j]); j++) {
          result += s1 + '\n'
        }
      }
      this.addMessage(result)
    },
    showQueryResult (res) {
      console.log(res)
      this.query.type = ''
      this.query.size = ''
      this.query.result = ''
      this.query.list = []
      if (res instanceof Array) {
        this.query.list = res
      } else {
        this.query.type = res.type
        let isJson = res.data instanceof Object || res.data instanceof Array
        this.query.size = res.data instanceof Array ? res.data.length : 1
        let data = isJson ? JSON.stringify(res.data) : res.data
        this.query.result = data
      }
    }
  } */
}
</script>

<style>
.el-menu-item,
.el-menu-item div {
  height: 36px;
  line-height: 36px;
  padding: 0;
}

.add-box {
  padding-left: 30px;
}

.el-menu-item i.el-icon-plus {
  font-size: 12px;
  width: 12px;
  margin: 0 2px 0 0;
}

.el-col.el-col-14 {
  padding: 0;
}

.el-button {
  font-size: 12px;
  padding: 5px 8px;
}

.dbinfo.el-radio {
  width: 100%;
  margin-left: 30px;
}

.gen-para {
  margin-top: 20px;
  width: 100%;
}

.is-active {
  background-color: azure;
}
</style>
